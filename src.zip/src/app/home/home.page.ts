import { Component, EventEmitter, Output } from '@angular/core';
import { NavController } from '@ionic/angular';
import { ExamService } from '../services/exam-service.service';
import { Exam } from '../models/exam.model';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  // Variables
  activeStudent: Exam | undefined;

  @Output() examDetail: any = new EventEmitter();

  examsList: Exam[] = []; // all of the exam results
  averageCheck: boolean = false;
  numberCourses: number = 0;
  totalMark: number = 0;
  average: number = 0;
  average1: number = 0;
  average2: number = 0;

  constructor(
    private navController: NavController,
    private examService: ExamService,
  ) { }
  ngOnInit() {
    this.examsList = this.examService.getExams();
  }

  // Functions
  calculateAverages(): void {
    this.averageCheck = true;
    this.average = 0;
    if (this.examsList.length > 0) {
      let totalMark = 0;
      let totalMark1 = 0;
      let count1 = 0;
      let totalMark2 = 0;
      let count2 = 0;
      for (let exam of this.examsList) {
        totalMark += exam.score;
        if (exam.semester == 1) {
          totalMark1 += exam.score;
          count1++;
        } else if (exam.semester == 2) {
          totalMark2 += exam.score;
          count2++;
        }
      }
      this.average = (totalMark / this.examsList.length);
      this.average1 = 0;
      this.average2 = 0;
      if (count1 > 0) {
        this.average1 = totalMark1 / count1;
      }
      if (count2 > 0) {
        this.average2 = totalMark2 / count2;
      }
    }

  }

  updateExam(exam: Exam) {
    this.examService.updateExam(exam);
  }
  deleteExam(exam: Exam) {
    this.examService.deleteExam(exam);
  }

  // Get Exam which will be updated
  getExam(exam: Exam): void {
    this.examDetail.emit(exam);
  }
  // Forward to next page
  goToExam() {
    this.navController.navigateForward('/alter-exam');
  }
}
