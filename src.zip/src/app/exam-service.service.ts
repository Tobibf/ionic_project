import { Injectable } from '@angular/core';
import { Exam } from './home/exam.model';

@Injectable({
  providedIn: 'root'
})
export class ExamServiceService {

  examsList: Exam[] = []; // all of the exam results
  totalMark: number = 0;
  average: number = 0;

  constructor() { }
  calculateAverages(): void{
    this.average = this.totalMark/this.examsList.length;
    // this.examsList['score'].
  }

  addExam(exam: Exam): void {
    this.examsList.unshift({ ...exam });
  }
  updateExam(exam: Exam): void {
    this.examsList;
  }
  delete(exam: Exam): void {
    this.examsList.splice(this.examsList.indexOf(exam));
  }

  getExams(): Exam[] {
    return [...this.examsList];
  }
}
