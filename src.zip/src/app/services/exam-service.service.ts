import { Injectable } from '@angular/core';
import { Exam } from '../models/exam.model';

@Injectable({
  providedIn: 'root'
})
export class ExamService {

  examsList: Exam[] = [
    {
      course: "IA",
      score: 4,
      semester: 1
    },
    {
      course: "English",
      score: 14,
      semester: 1
    },
    {
      course: "JAVA EE",
      score: 20,
      semester: 2
    }
  ]; // all of the exam results
  totalMark: number = 0;
  average: number = 0;

  constructor() { }
  calculateAverages(): void {
    this.average = this.totalMark / this.examsList.length;
    // this.examsList['score'].
  }

  addExam(exam: Exam): void {
    this.examsList.unshift({ ...exam });
    console.log(this.examsList);
  }
  updateExam(exam: Exam): void {
    this.examsList.fill;
    console.log(this.examsList);
  }

  deleteExam(exam: Exam): void {
    this.examsList.splice(this.examsList.indexOf(exam), 1);
    console.log(this.examsList);
  }

  getExams(): Exam[] {
    console.log(this.examsList);
    return [...this.examsList];
  }
}
