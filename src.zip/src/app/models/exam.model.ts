export interface Exam {
  score: number;
  course: string;
  semester: number;
}
